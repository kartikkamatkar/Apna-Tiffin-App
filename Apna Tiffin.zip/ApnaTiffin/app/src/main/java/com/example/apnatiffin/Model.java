package com.example.apnatiffin;

public class Model {
    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }

    int img;
        public String getMessname() {
            return Messname;
        }

        public void setMessname(String messname) {
            Messname = messname;
        }

        public String getLocation() {
            return Location;
        }

        public void setLocation(String location) {
            Location = location;
        }

        String Messname,Location;


}
